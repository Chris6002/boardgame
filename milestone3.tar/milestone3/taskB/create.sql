DROP DATABASE IF EXISTS lli50_1;
CREATE DATABASE lli50_1;

USE lli50_1;

CREATE TABLE games
(
	gameID					INT 			PRIMARY KEY		NOT NULL		AUTO_INCREMENT,
    name					VARCHAR(100) 	NOT NULL,
    mechanic				VARCHAR(45)		NOT NULL,
    bgg_url					VARCHAR(500)		NOT NULL,
    image_url				VARCHAR(500),
    cat_id					INT				NOT NULL
    );
    
CREATE TABLE player
(
	gameID 					INT 			PRIMARY KEY		NOT NULL,
    name					VARCHAR(500)	NOT NULL,
    min_player				INT,
    max_player				INT,
    age						VARCHAR(45)
    );

CREATE TABLE information
(
	gameID 					INT 			PRIMARY KEY		NOT NULL,
    name					VARCHAR(100)	NOT NULL,
    avg_rating				DOUBLE,
    geek_rating				DOUBLE,
    max_time				INT,
    min_time				INT,
    avg_time				INT 
    );

CREATE TABLE users
(
	email					VARCHAR(45)		PRIMARY KEY		NOT NULL,
    name					VARCHAR(45)		NOT NULL,
    password				VARCHAR(45)		NOT NULL
    );
    
CREATE TABLE bookmark
(
	email					VARCHAR(45)	 	NOT NULL,
    gameID					INT 	    	NOT NULL,
    PRIMARY KEY (email, gameID)
    );

CREATE TABLE category
(
	ID						INT 			PRIMARY KEY		NOT NULL	AUTO_INCREMENT,
    name					VARCHAR(45)		NOT NULL,
    reco_cat				INT 
    );

    
    